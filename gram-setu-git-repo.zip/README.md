# Gram Setu — Rural Economy Platform

**"Setu" means bridge.** This app is a bridge between rural producers, workers,
entrepreneurs, and the markets, jobs, and capital they're normally cut off from.

A working prototype (frontend, localStorage-backed) that demonstrates a scalable
model for strengthening rural economies — built as a foundation you can wire up
to a real backend, SMS gateway, or government data API.

---

## Problem → Solution mapping

| Problem | Module | How it scales |
|---|---|---|
| Middlemen erode farmer income | **Marketplace** | Direct listing/discovery, transparent pricing, no intermediary fee |
| Low agricultural productivity | **Advisory** | Crop calendar, weather-linked tips, pest/soil alerts — pushed, not pulled |
| Rural unemployment / distress migration | **Job Board** | Hyperlocal gig + agri-labor + govt scheme postings, filterable by skill & distance |
| Weak entrepreneurship pipeline | **Skill & Credit Hub** | SHG/microfinance directory + skill-training listings in one place |
| Fragmented, low-bargaining-power smallholders | **FPO Directory** | Lists local Farmer Producer Organizations for pooled selling/buying |

## Why this design scales

- **Mobile-first, low-bandwidth**: plain HTML/CSS/JS, no heavy framework, works
  on 2G/3G and cheap Android devices — the actual hardware reality in most
  rural regions.
- **Offline-tolerant data model**: all modules read/write through a single
  `js/store.js` data layer. Swapping `localStorage` for a real API
  (Node/Express, Supabase, Firebase, or a government open-data backend) is a
  one-file change — nothing in the UI layer needs to know.
- **Composable, not monolithic**: each module (Marketplace, Jobs, Advisory,
  Skill & Credit) is an independent tab/component. You can deploy just one
  module to a specific district pilot and add the rest later.
- **Vernacular-ready**: all UI copy lives in `js/copy.js` as a single object,
  so translating to regional languages is a translation task, not a
  re-engineering task.

## Project structure

```
rural-connect/
├── index.html          # App shell + tab navigation
├── css/
│   └── style.css        # Design system (tokens, layout, components)
├── js/
│   ├── store.js          # Data layer (localStorage now, swap for API later)
│   ├── copy.js            # All UI text (i18n-ready)
│   └── app.js               # Rendering + interaction logic
├── data/
│   └── seed.js                # Sample seed data for demo/testing
└── README.md
```

## Running it

No build step. Just open `index.html` in a browser, or serve it:

```bash
python3 -m http.server 8080
# then visit http://localhost:8080
```

## Roadmap to a real deployment

1. **Backend**: Replace `js/store.js` localStorage calls with REST calls to a
   Node/Express + Postgres (or Supabase) backend. Schema is already
   flat/normalized in `data/seed.js` to make this a near 1:1 mapping.
2. **SMS/IVR layer**: Add a Twilio/Exotel integration so farmers without
   smartphones can query advisory info and post job/produce listings via SMS.
3. **Auth**: Add phone-OTP login (most reliable rural auth pattern) — no
   email/password.
4. **Payments**: Integrate UPI (India) or mobile money for marketplace
   transactions and microfinance disbursement tracking.
5. **Regional language packs**: Populate `js/copy.js` with translations;
   add a language switcher.
6. **Pilot → scale**: Launch in one block/taluk, measure listing volume and
   job-fill rate, then replicate the same stack per district — the whole
   point of this architecture is that scaling is "deploy again," not
   "rebuild."

## License

MIT — see `LICENSE`.
