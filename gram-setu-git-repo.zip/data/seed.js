// Seed data — used only if localStorage is empty (first run / reset).
// In a real deployment this would come from a district-level API.

const SEED_DATA = {
  produce: [
    { id: "p1", crop: "Tomato", qty: "400 kg", price: "₹18/kg", village: "Kannamangalam", seller: "M. Selvi", status: "open" },
    { id: "p2", crop: "Turmeric (dried)", qty: "120 kg", price: "₹145/kg", village: "Adiyannamalai", seller: "R. Murugan", status: "open" },
    { id: "p3", crop: "Groundnut", qty: "800 kg", price: "₹62/kg", village: "Vettavalam", seller: "K. Pandiyan", status: "open" },
    { id: "p4", crop: "Banana (Nendran)", qty: "1.2 tonnes", price: "₹22/kg", village: "Chengam", seller: "S. Lakshmi", status: "reserved" },
    { id: "p5", crop: "Millets (Ragi)", qty: "300 kg", price: "₹38/kg", village: "Polur", seller: "V. Muthu", status: "open" }
  ],

  jobs: [
    { id: "j1", title: "Harvest labour — paddy", type: "Agri-labour", pay: "₹450/day", location: "Thandrampet", posted: "2 days ago", status: "open" },
    { id: "j2", title: "Tailoring assistant (SHG unit)", type: "Skilled — non-farm", pay: "₹9,000/month", location: "Tiruvannamalai town", posted: "5 days ago", status: "open" },
    { id: "j3", title: "MGNREGA — pond desilting work", type: "Government scheme", pay: "₹319/day", location: "Vandavasi block", posted: "1 day ago", status: "open" },
    { id: "j4", title: "Dairy cooperative — milk collection helper", type: "Agri-allied", pay: "₹8,500/month", location: "Cheyyar", posted: "1 week ago", status: "filled" },
    { id: "j5", title: "Solar panel installation trainee", type: "Skilled — non-farm", pay: "₹12,000/month", location: "Polur", posted: "3 days ago", status: "open" }
  ],

  training: [
    { id: "t1", name: "Organic farming certification", provider: "Krishi Vigyan Kendra", duration: "5 days", cost: "Free", seats: 12 },
    { id: "t2", name: "Tailoring & garment making", provider: "Rural Skill Mission", duration: "3 months", cost: "₹500 (subsidised)", seats: 20 },
    { id: "t3", name: "Basic bookkeeping for micro-enterprises", provider: "District Industries Centre", duration: "2 days", cost: "Free", seats: 30 },
    { id: "t4", name: "Solar panel installation & maintenance", provider: "Skill India", duration: "6 weeks", cost: "Free", seats: 15 }
  ],

  finance: [
    { id: "f1", name: "Self-Help Group — Ponni Mahalir Sangam", type: "SHG micro-savings & loan", ticket: "₹5,000 – ₹50,000", contact: "SHG Federation Office, Tiruvannamalai" },
    { id: "f2", name: "NABARM Kisan Credit Card", type: "Crop loan", ticket: "Up to ₹3,00,000", contact: "Nearest cooperative bank branch" },
    { id: "f3", name: "PM Mudra Yojana — Shishu", type: "Micro-enterprise loan", ticket: "Up to ₹50,000", contact: "Any nationalised bank branch" },
    { id: "f4", name: "PMEGP subsidy scheme", type: "New enterprise capital subsidy", ticket: "15–35% subsidy on project cost", contact: "District Industries Centre" }
  ],

  fpo: [
    { id: "o1", name: "Vettavalam Farmers Producer Co.", crops: "Groundnut, Millets", members: 340, contact: "vettavalam.fpo@example.org" },
    { id: "o2", name: "Chengam Banana Growers Collective", crops: "Banana", members: 210, contact: "chengambanana.fpo@example.org" },
    { id: "o3", name: "Polur Millet Producers Org.", crops: "Ragi, Bajra", members: 175, contact: "polurmillet.fpo@example.org" }
  ]
};
