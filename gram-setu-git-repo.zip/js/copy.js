// All user-facing text lives here. Translating the app to a regional
// language is a matter of populating a sibling object (e.g. COPY_TA)
// and switching which one app.js reads from.

const COPY = {
  appName: "Gram Setu",
  tagline: "The bridge between rural work and rural markets",

  tabs: {
    home: "Overview",
    marketplace: "Marketplace",
    jobs: "Jobs Board",
    training: "Skill & Credit",
    fpo: "Producer Groups"
  },

  home: {
    heroLabel: "District pilot — Tiruvannamalai block",
    heroLine1: "Five gaps.",
    heroLine2: "One bridge.",
    heroBody:
      "Gram Setu connects what rural communities already have — crops, labour, skills, and cooperative strength — to the markets, employers, and capital that are usually a bus ride and a broker's fee away.",
    statLabel1: "Active produce listings",
    statLabel2: "Open job postings",
    statLabel3: "Training seats available",
    statLabel4: "Producer groups listed"
  },

  marketplace: {
    title: "Sell direct. No middleman cut.",
    body: "List what you've harvested. Buyers see it immediately, at the price you set.",
    formTitle: "List your produce",
    fields: { crop: "Crop", qty: "Quantity", price: "Price", village: "Your village", seller: "Your name" },
    submit: "List produce",
    empty: "No listings yet. Be the first."
  },

  jobs: {
    title: "Find work near home",
    body: "Agri-labour, non-farm skilled work, and government scheme postings — all in one board.",
    formTitle: "Post a job",
    fields: { title: "Job title", type: "Category", pay: "Pay", location: "Location" },
    submit: "Post job",
    empty: "No openings yet."
  },

  training: {
    trainingTitle: "Build a new skill",
    financeTitle: "Find credit & savings groups",
    trainingBody: "Certified, low-cost training tied to real local employer demand.",
    financeBody: "Self-help groups, government loan schemes, and enterprise subsidies."
  },

  fpo: {
    title: "Producer groups near you",
    body: "Pooling with other growers means better prices, shared machinery, and real bargaining power."
  },

  common: {
    reset: "Reset demo data",
    status: { open: "Open", reserved: "Reserved", filled: "Filled" }
  }
};
