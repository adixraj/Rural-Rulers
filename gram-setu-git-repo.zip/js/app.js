// App rendering + interaction. Reads via Store, text via COPY.

document.addEventListener("DOMContentLoaded", () => {
  Store.init();
  renderHome();
  renderMarketplace();
  renderJobs();
  renderTrainingAndFinance();
  renderFPO();
  bindTabs();
  bindForms();
  bindReset();
});

function bindTabs() {
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
      document.querySelectorAll(".panel").forEach((p) => p.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById(btn.dataset.target).classList.add("active");
    });
  });
}

function bindReset() {
  document.getElementById("reset-btn").addEventListener("click", () => {
    Store.reset();
    location.reload();
  });
}

function statusStamp(status) {
  const label = COPY.common.status[status] || status;
  return `<span class="stamp ${status}">${label}</span>`;
}

/* ---------------------------------------------------------------- Home */
function renderHome() {
  const produce = Store.getAll("produce").filter((p) => p.status === "open").length;
  const jobs = Store.getAll("jobs").filter((j) => j.status === "open").length;
  const seats = Store.getAll("training").reduce((sum, t) => sum + (t.seats || 0), 0);
  const fpo = Store.getAll("fpo").length;

  document.getElementById("stat-produce").textContent = produce;
  document.getElementById("stat-jobs").textContent = jobs;
  document.getElementById("stat-seats").textContent = seats;
  document.getElementById("stat-fpo").textContent = fpo;
}

/* --------------------------------------------------------- Marketplace */
function renderMarketplace() {
  const list = Store.getAll("produce");
  const el = document.getElementById("marketplace-list");
  if (!list.length) {
    el.innerHTML = `<p>${COPY.marketplace.empty}</p>`;
    return;
  }
  el.innerHTML = list
    .map(
      (p) => `
    <div class="ledger-row">
      <div class="row-main"><strong>${p.crop}</strong><span>${p.village} — listed by ${p.seller}</span></div>
      <div class="row-detail">${p.qty}</div>
      <div class="row-detail">${p.price}</div>
      <div>${statusStamp(p.status)}</div>
    </div>`
    )
    .join("");
}

/* ------------------------------------------------------------- Jobs */
function renderJobs() {
  const list = Store.getAll("jobs");
  const el = document.getElementById("jobs-list");
  if (!list.length) {
    el.innerHTML = `<p>${COPY.jobs.empty}</p>`;
    return;
  }
  el.innerHTML = list
    .map(
      (j) => `
    <div class="ledger-row">
      <div class="row-main"><strong>${j.title}</strong><span>${j.type} · ${j.location}</span></div>
      <div class="row-detail">${j.pay}</div>
      <div class="row-meta">${j.posted || ""}</div>
      <div>${statusStamp(j.status)}</div>
    </div>`
    )
    .join("");
}

/* ------------------------------------------------ Training & Finance */
function renderTrainingAndFinance() {
  const training = Store.getAll("training");
  const finance = Store.getAll("finance");

  document.getElementById("training-list").innerHTML = training
    .map(
      (t) => `
    <div class="card">
      <h3>${t.name}</h3>
      <p>${t.provider} · ${t.duration}</p>
      <p>${t.cost} · ${t.seats} seats open</p>
    </div>`
    )
    .join("");

  document.getElementById("finance-list").innerHTML = finance
    .map(
      (f) => `
    <div class="card">
      <h3>${f.name}</h3>
      <p>${f.type}</p>
      <p>Ticket size: ${f.ticket}</p>
      <span class="tag">${f.contact}</span>
    </div>`
    )
    .join("");
}

/* --------------------------------------------------------------- FPO */
function renderFPO() {
  const list = Store.getAll("fpo");
  document.getElementById("fpo-list").innerHTML = list
    .map(
      (o) => `
    <div class="card">
      <h3>${o.name}</h3>
      <p>Crops: ${o.crops}</p>
      <p>${o.members} member farmers</p>
      <span class="tag">${o.contact}</span>
    </div>`
    )
    .join("");
}

/* ------------------------------------------------------------- Forms */
function bindForms() {
  const marketForm = document.getElementById("marketplace-form");
  marketForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const fd = new FormData(marketForm);
    Store.add("produce", {
      crop: fd.get("crop"),
      qty: fd.get("qty"),
      price: fd.get("price"),
      village: fd.get("village"),
      seller: fd.get("seller"),
      status: "open"
    });
    marketForm.reset();
    renderMarketplace();
    renderHome();
  });

  const jobForm = document.getElementById("jobs-form");
  jobForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const fd = new FormData(jobForm);
    Store.add("jobs", {
      title: fd.get("title"),
      type: fd.get("type"),
      pay: fd.get("pay"),
      location: fd.get("location"),
      posted: "just now",
      status: "open"
    });
    jobForm.reset();
    renderJobs();
    renderHome();
  });
}
