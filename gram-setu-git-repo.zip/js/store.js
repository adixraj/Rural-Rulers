// Data layer. Every read/write in the app goes through this module.
// Swap the body of these functions for `fetch()` calls to a real API
// and nothing else in the app needs to change.

const STORE_KEY = "gramsetu_data_v1";

const Store = {
  init() {
    if (!localStorage.getItem(STORE_KEY)) {
      localStorage.setItem(STORE_KEY, JSON.stringify(SEED_DATA));
    }
  },

  _read() {
    return JSON.parse(localStorage.getItem(STORE_KEY));
  },

  _write(data) {
    localStorage.setItem(STORE_KEY, JSON.stringify(data));
  },

  getAll(collection) {
    return this._read()[collection] || [];
  },

  add(collection, item) {
    const data = this._read();
    item.id = collection[0] + Date.now();
    data[collection].unshift(item);
    this._write(data);
    return item;
  },

  updateStatus(collection, id, status) {
    const data = this._read();
    const item = data[collection].find((i) => i.id === id);
    if (item) item.status = status;
    this._write(data);
  },

  reset() {
    localStorage.setItem(STORE_KEY, JSON.stringify(SEED_DATA));
  }
};
